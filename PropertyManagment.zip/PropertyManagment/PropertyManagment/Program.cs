using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Serialization;
using PropertyManagement.Business.Services;
using PropertyManagement.Business.Services.External;
using PropertyManagement.Data.Data;
using PropertyManagement.Data.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.OpenApi.Models;


var builder = WebApplication.CreateBuilder(args);









// Add services to the container.

builder.Services.AddControllers()
    .AddNewtonsoftJson(options =>
    {
        // Handle circular references by ignoring them or serializing them
       // options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
        options.SerializerSettings.ContractResolver = new DefaultContractResolver();
    });

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("PropertyDB")));


// Repositories
builder.Services.AddScoped<IGenericRepository, GenericRepository>();
builder.Services.AddScoped<IUserAccountRepository, UserAccountRepository>();
builder.Services.AddScoped<IBackOfficeUserAccountRepository, BackOfficeUserAccountRepository>();
builder.Services.AddScoped<IAgentUserAccountRepository, AgentUserAccountRepository>();
builder.Services.AddScoped<IBuyPropertyRepository, BuyPropertyRepository>();
builder.Services.AddScoped<IAgentRepository, AgentRepository>();
builder.Services.AddScoped<IBrokerRepository, BrokerRepository>();
builder.Services.AddScoped<IRentalPropertyRepository, RentalPropertyRepository>();
builder.Services.AddScoped<IFiltersRepository, FiltersRepository>();
builder.Services.AddScoped<INewProjectRepository, NewProjectRepository>();
builder.Services.AddScoped<IUserFavRepository, UserFavRepository>();
builder.Services.AddScoped<IPropertyConfigurationRepository, PropertyConfigurationRepository>();
builder.Services.AddScoped<IDeveloperRepository, DeveloperRepository>();
builder.Services.AddScoped<ICityRepository, CityRepository>();
builder.Services.AddScoped<ICountryRepository, CountryRepository>();
builder.Services.AddScoped<IAreaRepository, AreaRepository>();
builder.Services.AddScoped<ILanguageRepository, LanguageRepository>();










builder.Services.AddScoped<ITestDbRepo, TestDbRepo>();



// Services
builder.Services.AddScoped<ITestDbService, TestDbService>();
builder.Services.AddScoped<IVerifyGoogleAccessTokenService, VerifyGoogleAccessTokenService>();
builder.Services.AddScoped<IUserAccountService, UserAccountService>();
builder.Services.AddScoped<IBackOfficeUserAccountService, BackOfficeUserAccountService>();
builder.Services.AddScoped<IUserTokenService, UserTokenService>();
builder.Services.AddScoped<IBackOfficeTokenService, BackOfficeTokenService>();
builder.Services.AddScoped<IAgentUserTokenService, AgentUserTokenService>();
builder.Services.AddScoped<IAgentUserAccountService, AgentUserAccountService>();
builder.Services.AddScoped<IBuyPropertyService, BuyPropertyService>();
builder.Services.AddScoped<IAgentService, AgentService>();
builder.Services.AddScoped<IBrokerService, BrokerService>();
builder.Services.AddScoped<IRentalPropertyService, RentalPropertyService>();
builder.Services.AddScoped<IFiltersService, FiltersService>();
builder.Services.AddScoped<INewProjectService, NewProjectService>();
builder.Services.AddScoped<IUserFavService, UserFavService>();
builder.Services.AddScoped<IPropertyConfigurationService, PropertyConfigurationService>();
builder.Services.AddScoped<IDeveloperService, DeveloperService>();
builder.Services.AddScoped<ICityService, CityService>();
builder.Services.AddScoped<ICountryService, CountryService>();
builder.Services.AddScoped<IAreaService, AreaService>();
builder.Services.AddScoped<ILanguageService, LanguageService>();












builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false;  // Set to true in production
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:SecretKey"]!))
        };
    });
builder.Services.AddHttpClient();
builder.Services.AddSwaggerGen(c => {
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "PropertyManagment.Api",
        Version = "v1"
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme {
                Reference = new OpenApiReference {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
