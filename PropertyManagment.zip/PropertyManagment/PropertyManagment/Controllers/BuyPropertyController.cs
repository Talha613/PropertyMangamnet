using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;


namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class BuyPropertyController : ControllerBase
{
    private readonly IBuyPropertyService _buyPropertyService;
    public BuyPropertyController(IBuyPropertyService buyPropertyService)
    {
        _buyPropertyService = buyPropertyService;
    }

    [HttpPost("get_buy_properties")]
    public async Task<IActionResult> BuyProperties(GetBuyPropertiesRequest request)
    {
        var data = await _buyPropertyService.GetBuyProperties(request);
        return Ok(data);
    }

    [HttpPost("create_update_buy_property")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateUpdateRentalProperty(BuyPropertyRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _buyPropertyService.InsertUpdateBuyProperty(request);
        return Ok(data);
    }



    [HttpGet("get_buy_properties_details")]
    public async Task<IActionResult> BuyProperties(int propertyId)
    {
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var data = await _buyPropertyService.GetBuyPropertyDetails(propertyId, language);
        return Ok(data);
    }


    [HttpPost("create_buy_property_details")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateBuyPropertyDetails(InsertBuyPropertyDetailMapRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        var data = await _buyPropertyService.InsertBuyPropertyDetailMap(request);
        return Ok(data);
    }


    [HttpPost("create_buy_property_media")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateRentalPropertyMedia(InsertBuyPropertyMediaRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        var data = await _buyPropertyService.InsertBuyPropertyMedia(request);
        return Ok(data);
    }

    [HttpPost("create_buy_property_mortgage_cost")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateBuyPropertyMortgageCost(PropertyPurchaseMortgageCostRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreatedBy = Convert.ToInt32(id!);
        var data = await _buyPropertyService.InsertPropertyPurchaseMortgageCosts(request);
        return Ok(data);
    }

    [HttpPost("create_buy_property_cash_cost")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateBuyPropertyCashCost(PropertyPurchaseCostsCashRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreatedBy = Convert.ToInt32(id!);
        var data = await _buyPropertyService.InsertPropertyPurchaseCostsCash(request);
        return Ok(data);
    }


    [HttpPost("get_buy_properties_list")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> GetBuyProperties(PaginatedRequest request)
    {
        var data = await _buyPropertyService.GetBuyPropertiesForPanel(request);
        return Ok(data);
    }
    [HttpGet("get_buy_property_media_for_admin")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> GetBuyPropertyMedia(int buyPropertyId)
    {
        var data = await _buyPropertyService.GetMediaByBuyPropertyIdForAdminPanel(buyPropertyId);
        return Ok(data);
    }

    [HttpGet("get_buy_property_cash_for_admin")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> GetBuyPropertyCash(int buyPropertyId)
    {
        var data = await _buyPropertyService.GetPropertyPurchaseCostsCashByBuyPropertyId(buyPropertyId);
        return Ok(data);
    }

    [HttpGet("get_buy_property_mortgage_for_admin")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> GetBuyPropertyMortgage(int buyPropertyId)
    {
        var data = await _buyPropertyService.GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel(buyPropertyId);
        return Ok(data);
    }
}

