using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class DeveloperController : ControllerBase
{
    private readonly IDeveloperService _developerService;
    public DeveloperController(IDeveloperService developerService)
    {
        _developerService = developerService;
    }


    [HttpPost("create_update_developer")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateDeveloper(InsertUpdateDeveloperRequest request)
    {
        var data = await _developerService.InsertUpdateDeveloper(request);
        return Ok(data);
    }

    [HttpPost("get_developer")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetConfigDetail(PaginatedRequest request)
    {
        var data = await _developerService.GetDevelopers(request);
        return Ok(data);
    }


}

