using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ICityService _cityService;
        public CityController(ICityService cityService)
        {
            _cityService = cityService;
    }



    [HttpPost("create_update_cities")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateCity(InsertUpdateCityRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id);
        request.UpdateBy = Convert.ToInt32(id);
        var data = await _cityService.InsertUpdateCity(request);
        return Ok(data);
    }
    [HttpPost("get_cities")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetCities(PaginatedRequest request)
    {
        var data = await _cityService.GetCities(request);
        return Ok(data);
    }
}

