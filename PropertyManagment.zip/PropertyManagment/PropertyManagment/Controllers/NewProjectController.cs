using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;


namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class NewProjectController : ControllerBase
{
    private readonly INewProjectService _newProjectService;
    public NewProjectController(INewProjectService newProjectService)
    {
        _newProjectService = newProjectService;
    }

    [HttpPost("get_new_project")]
    public async Task<IActionResult> GetNewProject(GetNewProjectsRequest request)
    {
        var data = await _newProjectService.GetNewProjects(request);
        return Ok(data);
    }
    [HttpGet("get_new_project_details")]
    public async Task<IActionResult> GetNewProjectDetails(int projectId)
    {
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var data = await _newProjectService.GetNewProjectDetails(projectId, language);
        return Ok(data);
    }

    [HttpPost("create_update_project")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateProject(InsertUpdateNewProjectRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertUpdateNewProject(request);
        return Ok(data);
    }


    [HttpPost("create_project_media")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateProjectMedia(InsertNewProjectMediaRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertNewProjectMedia(request);
        return Ok(data);
    }


    [HttpPost("create_project_details")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateProjectDetails(InsertNewProjectsDetailMapRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertNewProjectsDetailMap(request);
        return Ok(data);
    }


    [HttpDelete("delete_project")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteNewProject(int projectId)
    {
        var data = await _newProjectService.DeleteNewProject(projectId);
        return Ok(data);
    }



    [HttpPost("create_update_project_payment_plan")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateProjectPaymentPlan(InsertUpdatePaymentPlanRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertUpdatePaymentPlan(request);
        return Ok(data);
    }



    [HttpPost("create_update_project_payment_plan_details")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateProjectPaymentPlanDetails(InsertUpdateProjectPaymentPlanDetailRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertUpdateProjectPaymentPlanDetails(request);
        return Ok(data);
    }



    [HttpPost("create_update_project_timeline")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateProjectTimeLine(InsertUpdateProjectTimelineRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertUpdateProjectTimeline(request);
        return Ok(data);
    }


    [HttpPost("create_update_project_unit")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateUnit(InsertUpdateProjectUnitRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _newProjectService.InsertUpdateProjectUnit(request);
        return Ok(data);
    }


    [HttpPost("get_projects_list")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetAgentUsers(PaginatedRequest request)
    {
        var data = await _newProjectService.GetProjects(request);
        return Ok(data);
    }

    [HttpGet("get_project_media_for_admin")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetProjectMedia(int projectId)
    {
        var data = await _newProjectService.GetMediaByProjectIdForAdminPanel(projectId);
        return Ok(data);
    }

    [HttpGet("get_project_units_for_admin")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetProjectUnits(int projectId)
    {
        var data = await _newProjectService.GetUnitByProjectIdForAdmin(projectId);
        return Ok(data);
    }

    [HttpGet("get_project_timeline_for_admin")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetProjectTimeLine(int projectId)
    {
        var data = await _newProjectService.GetProjectTimelineByProjectIdForAdmin(projectId);
        return Ok(data);
    }

}

