using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class CountryController : ControllerBase
{
    private readonly ICountryService _countryService;
    public CountryController(ICountryService countryService)
    {
        _countryService = countryService;
    }



    [HttpPost("create_update_countries")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateCountry(InsertUpdateCountryRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id);
        request.UpdateBy = Convert.ToInt32(id);
        var data = await _countryService.InsertUpdateCountry(request);
        return Ok(data);
    }


    [HttpPost("get_countries")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetCountry(PaginatedRequest request)
    {
        var data = await _countryService.GetCountries(request);
        return Ok(data);
    }


}

