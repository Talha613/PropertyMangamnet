using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using System.Security.Claims;

namespace PropertyManagement.API.Controllers;
    [Route("api/[controller]")]
    [ApiController]
    public class UserAccountController : ControllerBase
    {
        private readonly IUserAccountService _userAccountService;
        public UserAccountController(IUserAccountService userAccountService)
        {
            _userAccountService = userAccountService;
    }

    [HttpPost("register_user")]
    public async Task<IActionResult> RegisterUser(RegisterUserRequest request)
    {
        var data = await _userAccountService.RegisterUser(request);
        return Ok(data);
    }
    [HttpPost("login_user")]
    public async Task<IActionResult> LoginUser(UserLoginRequest request)
    {
        var data = await _userAccountService.UserLogin(request);
        return Ok(data);
    }
    [HttpPost("change_user_password")]
    [Authorize]
    public async Task<IActionResult> ChangePasswordUser(string password)
    {
        var email = User.FindFirst(ClaimTypes.Email)?.Value; 
        UpdateUserPasswordRequest request = new UpdateUserPasswordRequest(email!,password);
        var data = await _userAccountService.UpdateUserPassword(request);
        return Ok(data);
    }
}

