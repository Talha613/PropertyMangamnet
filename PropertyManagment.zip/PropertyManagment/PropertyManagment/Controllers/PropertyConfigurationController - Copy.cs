using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class PropertyConfigurationController : ControllerBase
{
    private readonly IPropertyConfigurationService _propertyConfigurationService;
    public PropertyConfigurationController(IPropertyConfigurationService propertyConfigurationService)
    {
        _propertyConfigurationService = propertyConfigurationService;
    }


    [HttpPost("create_update_configuration_details")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateConfigDetail(InsertUpdatePropertyConfigurationDetailsRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.By = id!;
        var data = await _propertyConfigurationService.InsertUpdatePropertyConfigurationDetails(request);
        return Ok(data);
    }


    [HttpPost("get_configuration_details")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetConfigDetail(PaginatedRequest request)
    {
        var data = await _propertyConfigurationService.GetPropertyConfigurationDetail(request);
        return Ok(data);
    }


}

