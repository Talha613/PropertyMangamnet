using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
[Authorize]
public class FavController : ControllerBase
{
    private readonly IUserFavService _userFavService;
    private readonly IBuyPropertyService _buyPropertyService;
    private readonly IRentalPropertyService _rentalPropertyService;
    private readonly INewProjectService _newProjectService;



    public FavController(IUserFavService userFavService, IBuyPropertyService buyPropertyService, IRentalPropertyService rentalPropertyService,INewProjectService newProjectService)
    {
        _userFavService = userFavService;
        _buyPropertyService = buyPropertyService;
        _rentalPropertyService = rentalPropertyService;
        _newProjectService = newProjectService;
    }


    [HttpPost("add_user_buy_property_fav")]
    public async Task<IActionResult> AddUserBuyPropertyFav(int propertyId)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        var data = await _userFavService.InsertBuyPropertyUserFav(propertyId, Convert.ToInt32(id));
        return Ok(data);
    }

    [HttpGet("get_user_buy_property_fav")]
    public async Task<IActionResult> GetUserBuyPropertyFav(int pageNumber,int pageSize)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var request = new GetBuyPropertiesRequest(null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            Convert.ToInt32(id),
            pageNumber,
            pageSize,
            language);
        var data = await _buyPropertyService.GetBuyProperties(request);
        return Ok(data);
    }
    [HttpDelete("remove_user_buy_property_fav")]
    public async Task<IActionResult> RemoveUserBuyPropertyFav(int id)
    {
        var data = await _userFavService.RemoveBuyPropertyUserFav(id);
        return Ok(data);
    }
    [HttpGet("get_user_rent_property_fav")]
    public async Task<IActionResult> GetUserRentPropertyFav(int pageNumber, int pageSize)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var request = new GetRentalPropertiesRequest(null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            Convert.ToInt32(id),
            pageNumber,
            pageSize,
            language);
        var data = await _rentalPropertyService.GetRentalProperties(request);
        return Ok(data);
    }
    [HttpPost("add_user_rent_property_fav")]
    public async Task<IActionResult> AddUserRentPropertyFav(int propertyId)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        var data = await _userFavService.InsertRentPropertyUserFav(propertyId, Convert.ToInt32(id));
        return Ok(data);
    }
    [HttpDelete("remove_user_rent_property_fav")]
    public async Task<IActionResult> RemoveUserRentPropertyFav(int id)
    {
        var data = await _userFavService.RemoveRentPropertyUserFav(id);
        return Ok(data);
    }
    [HttpPost("add_user_new_project_fav")]
    public async Task<IActionResult> AddUserNewProjectFav(int propertyId)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        var data = await _userFavService.InsertNewProjectUserFav(propertyId, Convert.ToInt32(id));
        return Ok(data);
    }
    [HttpGet("get_user_new_project_fav")]
    public async Task<IActionResult> GetUserNewProjectFav(int pageNumber, int pageSize)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var request = new GetNewProjectsRequest(null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            Convert.ToInt32(id),
            pageNumber,
            pageSize,language
            );
        var data = await _newProjectService.GetNewProjects(request);
        return Ok(data);
    }
    [HttpDelete("remove_user_new_project_fav")]
    public async Task<IActionResult> RemoveUserNewProjectFav(int id)
    {
        var data = await _userFavService.RemoveNewProjectUserFav(id);
        return Ok(data);
    }


}

