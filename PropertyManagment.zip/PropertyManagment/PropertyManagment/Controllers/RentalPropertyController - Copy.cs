using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class RentalPropertyController : ControllerBase
{
    private readonly IRentalPropertyService _rentalPropertyService;
    public RentalPropertyController(IRentalPropertyService rentalPropertyService)
    {
        _rentalPropertyService = rentalPropertyService;
    }

    [HttpPost("get_rental_properties")]
    public async Task<IActionResult> RentalProperties(GetRentalPropertiesRequest request)
    {
        var data = await _rentalPropertyService.GetRentalProperties(request);
        return Ok(data);
    }



    [HttpGet("get_rental_properties_details")]
    public async Task<IActionResult> BuyProperties(int propertyId)
    {
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var data = await _rentalPropertyService.GetRentalPropertyDetails(propertyId, language);
        return Ok(data);
    }
    [HttpPost("create_update_rental_property")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateUpdateRentalProperty(RentalPropertyRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        request.UpdateBy = Convert.ToInt32(id!);
        var data = await _rentalPropertyService.InsertUpdateRentalProperty(request);
        return Ok(data);
    }

    [HttpPost("create_rental_property_media")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateRentalPropertyMedia(InsertRentalPropertyMediaRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        var data = await _rentalPropertyService.InsertRentalPropertyMedia(request);
        return Ok(data);
    }

    [HttpPost("create_rental_property_details")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateRentalPropertyDetails(InsertRentalPropertyDetailMapRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id!);
        var data = await _rentalPropertyService.InsertRentalPropertyDetailMap(request);
        return Ok(data);
    }


    [HttpPost("create_rental_property_costs")]
    [Authorize(Roles = "Agent")]
    public async Task<IActionResult> CreateRentalPropertyCosts(InsertRentalPropertyCostsRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreatedBy = Convert.ToInt32(id!);
        var data = await _rentalPropertyService.InsertRentalPropertyCosts(request);
        return Ok(data);
    }



}

