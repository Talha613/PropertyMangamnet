using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;
using PropertyManagement.Core.DTOs.Shared;

namespace PropertyManagement.API.Controllers;
[Route("api/[controller]")]
[ApiController]
public class LanguageController : ControllerBase
{
    private readonly ILanguageService _languageService;
    public LanguageController(ILanguageService languageService)
    {
        _languageService = languageService;
    }



    [HttpPost("create_update_language")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateUpdateLanguage(InsertUpdateLanguageRequest request)
    {
        var id = User.FindFirst(ClaimTypeDto.Id)?.Value;
        request.CreateBy = Convert.ToInt32(id);
        request.UpdateBy = Convert.ToInt32(id);
        var data = await _languageService.InsertUpdateLanguage(request);
        return Ok(data);
    }


    [HttpPost("get_languages")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetLanguages(PaginatedRequest request)
    {
        var data = await _languageService.GetLanguages(request);
        return Ok(data);
    }

}

