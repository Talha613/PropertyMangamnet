using Microsoft.AspNetCore.Mvc;
using PropertyManagement.Business.Services;

namespace PropertyManagement.API.Controllers;
    [Route("api/[controller]")]
    [ApiController]
    public class FilterController : ControllerBase
    {
        private readonly IFiltersService _filtersService;
        public FilterController(IFiltersService filtersService)
        {
            _filtersService = filtersService;
    }


    [HttpGet("get_filters_list")]
    public async Task<IActionResult> GetFiltersList()
    {
        var language = HttpContext.Request.Headers["Accept-Language"].ToString();
        var data = await _filtersService.GetFilters(language);
        return Ok(data);
    }
}

