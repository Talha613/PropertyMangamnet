﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel
{
       [Key]
        public int CashCostId { get; set; }
        public int BuyPropertyId { get; set; }
        public decimal PurchasePrice { get; set; }
        public decimal LandDeptFeePercentage { get; set; }
        public decimal AgencyFeePercentage { get; set; }
        public decimal AgencyFeeVatPercentage { get; set; }
        public decimal TrusteeFee { get; set; }
        public decimal ConveyancerFee { get; set; }
        public decimal TotalCost { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
}

