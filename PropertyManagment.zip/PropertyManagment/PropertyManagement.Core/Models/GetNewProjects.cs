﻿
namespace PropertyManagement.Core.Models;
public class GetNewProjects
{
    public Guid Id { get; set; }

    public int ProjectId { get; set; }

    public string ProjectStatus { get; set; } = string.Empty;

    public string ShortDescription { get; set; } = string.Empty;

    public string LaunchPrice { get; set; } = string.Empty;

    public string DeliveryDate { get; set; } = string.Empty;

    public string DeveloperName { get; set; } = string.Empty;

    public string Location { get; set; } = string.Empty;

    public string MediaType { get; set; } = string.Empty;

    public string MediaUrl { get; set; } = string.Empty;

    public string MediaMenu { get; set; } = string.Empty;

    public int TotalRecords { get; set; }

    public int TotalPages { get; set; }
}

