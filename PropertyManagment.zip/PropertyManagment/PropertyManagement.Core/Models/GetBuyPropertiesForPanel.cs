﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

public class GetBuyPropertiesForPanel
{
    [Key]
    public int BuyPropertyId { get; set; }
    public string? ShortDescription { get; set; }
    public string? LongDescription { get; set; }
    public string? BuildingName { get; set; }
    public int AreaId { get; set; }
    public double Longitude { get; set; }
    public double Latitude { get; set; }
    public int SquareFeet { get; set; }
    public int SquareMeter { get; set; }
    public int BedRooms { get; set; }
    public bool HaveMadeRoom { get; set; }
    public int Bathrooms { get; set; }
    public int PropertyTypeId { get; set; }
    public bool IsActive { get; set; }
    public bool IsApproved { get; set; }
    public int? ApprovedBy { get; set; }
    public int CreateBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public int? UpdateBy { get; set; }
    public DateTime? UpdatedAt { get; set; }


    public int RecordsTotal { get; set; }
    public int RecordsFiltered { get; set; }
    public int TotalPages { get; set; }

}

