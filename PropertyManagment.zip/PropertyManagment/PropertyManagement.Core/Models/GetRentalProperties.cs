﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;
public class GetRentalProperties
{
    [Key]
    public Guid Id { get; set; }
    public int RentalPropertyMediaId { get; set; }
    public int RentalPropertyId { get; set; }
    public int PropertyType { get; set; }
    public decimal Price { get; set; }
    public string ShortDescription { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public int Bedrooms { get; set; }
    public int Bathrooms { get; set; }
    public int SquareFeet { get; set; }
    public int SquareMeter { get; set; }
    public string Listed { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string WhatsApp { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string BrokerName { get; set; } = string.Empty;
    public string BrokerLogo { get; set; } = string.Empty;
    public string MediaType { get; set; } = string.Empty;
    public string MediaUrl { get; set; } = string.Empty;
    public string MediaMenu { get; set; } = string.Empty;
    public int TotalRecords { get; set; }
    public int TotalPages { get; set; }
}

public class GetRentalPropertiesAssociatedCounts
{
    public int Id { get; set; }
    [Key]
    public string Value { get; set; } = string.Empty;
    public int Count { get; set; }
    public string Type { get; set; } = string.Empty;

}