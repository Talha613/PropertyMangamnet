﻿

using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetLanguages
    {

        public int RecordsTotal { get; set; }       // Total number of records
        public int RecordsFiltered { get; set; }    // Filtered number of records
        public int TotalPages { get; set; }         // Total number of pages

        [Key]
        public int LanguageId { get; set; }
        public string LanguageCode { get; set; } = string.Empty;
        public string LanguageName { get; set; } = string.Empty;
         public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
}

