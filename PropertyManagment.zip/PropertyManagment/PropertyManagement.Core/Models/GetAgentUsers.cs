﻿

using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetAgentUsers
    {
        public int RecordsTotal { get; set; }
        public int RecordsFiltered { get; set; }
        public int TotalPages { get; set; }

        [Key]
        public int UserId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public decimal Experience { get; set; }
        public string ProfilePicture { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string WhatsApp { get; set; } = string.Empty;
        public int RealEstateBrokerId { get; set; }
        public bool IsActive { get; set; }
        public int CreateBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? UpdateBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
}

