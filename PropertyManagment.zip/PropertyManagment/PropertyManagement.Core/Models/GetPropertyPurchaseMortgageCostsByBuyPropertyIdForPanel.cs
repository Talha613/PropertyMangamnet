﻿
namespace PropertyManagement.Core.Models;

public class GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel
{
    public int MortgageCostId { get; set; }

    public int BuyPropertyId { get; set; }

    public decimal PurchasePrice { get; set; }

    public decimal DownPayment { get; set; }

    public decimal LandDeptFee { get; set; }

    public decimal TrusteeFee { get; set; }

    public decimal MortgageRegistrationFee { get; set; }

    public decimal AgencyFee { get; set; }

    public decimal BankArrangementFee { get; set; }

    public decimal ValuationFee { get; set; }

    public decimal AmountRequiredUpfront { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedAt { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

}

