﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;
public class GetRentalPropertyDetails
{
    public int RentalPropertyId { get; set; }
    [Key]
    public Guid Id { get; set; }
    public int RentalPropertyMediaId { get; set; }
    public string PropertyType { get; set; } = string.Empty;
    public string ShortDescription { get; set; } = string.Empty;
    public string LongDescription { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public DateTime? AvailableFrom { get; set; }
    public int Bedrooms { get; set; }
    public bool HaveMadeRoom { get; set; }
    public int Bathrooms { get; set; }
    public int SquareFeet { get; set; }
    public int SquareMeter { get; set; }
    public string Listed { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string ProfilePicture { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string WhatsApp { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string BrokerName { get; set; } = string.Empty;
    public string BrokerLogo { get; set; } = string.Empty;
    public string MediaType { get; set; } = string.Empty;
    public string MediaUrl { get; set; } = string.Empty;
    public string MediaMenu { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
}


public class GetRentalPropertyCosts
{
    [Key]
    public int UpfrontCostId { get; set; }

    public int RentPropertyId { get; set; }

    public decimal AnnualRent { get; set; }

    public decimal AgencyFeePercentage { get; set; }

    public decimal AgencyFeeVatPercentage { get; set; }

    public decimal SecurityDeposit { get; set; }

    public decimal DewaDeposit { get; set; }

    public decimal EjariFee { get; set; }

    public decimal TotalUpfrontCosts { get; set; }
}
