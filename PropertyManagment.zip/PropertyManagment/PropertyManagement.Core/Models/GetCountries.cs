﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetCountries
    {
        public int RecordsTotal { get; set; }       // Total number of records
        public int RecordsFiltered { get; set; }    // Filtered number of records
        public int TotalPages { get; set; }         // Total number of pages
       [Key]
        public int CountryId { get; set; }
        public string CountryName { get; set; } = string.Empty;
        public string CountryCode { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public int CreateBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? UpdateBy { get; set; }        // Nullable, as it might not be set for some records
        public DateTime? UpdatedAt { get; set; }
}

