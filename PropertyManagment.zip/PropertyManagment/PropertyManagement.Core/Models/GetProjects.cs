﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

public class GetProjects
{

    public int RecordsTotal { get; set; }
    public int RecordsFiltered { get; set; }
    public int TotalPages { get; set; }
    [Key]
    public int ProjectId { get; set; }                  // Unique identifier for the project
    public int ProjectStatus { get; set; }             // Status of the project
    public int DeveloperId { get; set; }               // Developer associated with the project
    public int AreaId { get; set; }                    // Area ID associated with the project
    public string? CommunityName { get; set; }          // Name of the community
    public decimal? GovFee { get; set; }                // Government fee percentage or amount
    public string? ShortDescription { get; set; }       // Brief description of the project
    public string? LongDescription { get; set; }        // Detailed description of the project
    public decimal? LaunchPrice { get; set; }          // Launch price of the project (nullable)
    public DateTime? DeliveryDate { get; set; }        // Delivery date for the project (nullable)
    public DateTime? SalesStart { get; set; }          // Sales start date (nullable)
    public int? NumberOfBuildings { get; set; }        // Number of buildings in the project (nullable)
    public int? PropertyTypeId { get; set; }           // Property type identifier (nullable)
    public int CreateBy { get; set; }                  // ID of the user who created the record
    public DateTime CreateAt { get; set; }             // Timestamp when the record was created
    public int? UpdateBy { get; set; }                 // ID of the user who last updated the record (nullable)
    public DateTime? UpdateAt { get; set; }            // Timestamp when the record was last updated (nullable)
 


}

