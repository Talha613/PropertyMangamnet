﻿

namespace PropertyManagement.Core.Models;
public class GetFilters
{
        public int Id { get; set; }
        public string ConfigKey { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;

}

