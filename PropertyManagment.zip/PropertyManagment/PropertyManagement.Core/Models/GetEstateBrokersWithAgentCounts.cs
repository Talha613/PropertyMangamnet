﻿

using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;
public class GetEstateBrokersWithAgentCounts
{
    [Key]
    public int RealEstateBrokerId { get; set; }
    public string BrokerName { get; set; } = string.Empty;
    public int Orn { get; set; }
    public string Address { get; set; } = string.Empty;
    public string BrokerEmail { get; set; } = string.Empty;
    public string BrokerPhone { get; set; } = string.Empty;
    public string Logo { get; set; } = string.Empty;
    public string About { get; set; } = string.Empty;
    public int AgentCount { get; set; }
    public int TotalRecords { get; set; }
    public int TotalPages { get; set; }
}

