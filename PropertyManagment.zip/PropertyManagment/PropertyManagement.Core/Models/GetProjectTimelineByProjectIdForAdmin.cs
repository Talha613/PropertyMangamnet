﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetProjectTimelineByProjectIdForAdmin
{
        [Key]
        public int ProjectTimelineId { get; set; }
        public int ProjectId { get; set; }
        public int? TimeLineConfigId { get; set; } // Nullable in case it's not always provided
        public DateTime? Date { get; set; } // Nullable DateTime
        public DateTime CreatedAt { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; } // Nullable DateTime
        public int? UpdatedBy { get; set; } // Nullable in case not updated
}



