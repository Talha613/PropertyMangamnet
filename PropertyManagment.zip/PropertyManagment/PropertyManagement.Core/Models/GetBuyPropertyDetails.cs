﻿using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;
public class GetBuyPropertyDetails
{
    public int BuyPropertyId { get; set; }
    [Key] 
    public Guid Id { get; set; }
    public int BuyPropertyMediaId { get; set; }
    public string PropertyType { get; set; } = string.Empty;
    public string ShortDescription { get; set; } = string.Empty;
    public string LongDescription { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public int Bedrooms { get; set; }
    public bool HaveMadeRoom { get; set; }
    public int Bathrooms { get; set; }
    public int SquareFeet { get; set; }
    public int SquareMeter { get; set; }
    public string Listed { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string ProfilePicture { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string WhatsApp { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string BrokerName { get; set; } = string.Empty;
    public string BrokerLogo { get; set; } = string.Empty;
    public string MediaType { get; set; } = string.Empty;
    public string MediaUrl { get; set; } = string.Empty;
    public string MediaMenu { get; set; } = string.Empty;

    public string Value { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
}

public class GetBuyPropertyPurchaseCostsCash
{
    [Key]
    public int CashCostId { get; set; }
    public int BuyPropertyId { get; set; }
    public decimal PurchasePrice { get; set; }
    public decimal LandDeptFeePercentage { get; set; }
    public decimal AgencyFeePercentage { get; set; }
    public decimal AgencyFeeVatPercentage { get; set; }
    public decimal TrusteeFee { get; set; }
    public decimal ConveyancerFee { get; set; }
    public decimal TotalCost { get; set; }
}

public class GetBuyPropertyPurchaseMortgageCosts
{
    [Key]
    public int MortgageCostId { get; set; }
    public int BuyPropertyId { get; set; }
    public decimal PurchasePrice { get; set; }
    public decimal DownPayment { get; set; }
    public decimal LandDeptFee { get; set; }
    public decimal TrusteeFee { get; set; }
    public decimal MortgageRegistrationFee { get; set; }
    public decimal AgencyFee { get; set; }
    public decimal BankArrangementFee { get; set; }
    public decimal ValuationFee { get; set; }
    public decimal AmountRequiredUpfront { get; set; }
}

