﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

public class GetUnitByProjectIdForAdmin
{
    [Key]
    public int ProjectUnitId { get; set; }

    public int ProjectId { get; set; }

    public int PropertyTypeId { get; set; }

    public int Bed { get; set; }

    public string LayoutType { get; set; } = string.Empty;

    public decimal? Price { get; set; }

    public int Sqft { get; set; }

    public string? FloorPlanUrl { get; set; }

    public DateTime CreateAt { get; set; }

    public int CreateBy { get; set; }

    public DateTime? UpdateAt { get; set; }

    public int? UpdateBy { get; set; }

}
