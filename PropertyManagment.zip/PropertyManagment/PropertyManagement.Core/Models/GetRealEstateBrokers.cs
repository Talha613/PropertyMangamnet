﻿

using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetRealEstateBrokers
    {
        public int RecordsTotal { get; set; }
    public int RecordsFiltered { get; set; }
    public int TotalPages { get; set; }
    [Key]
        public int RealEstateBrokerId { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Orn { get; set; } 
    public string Office { get; set; } = string.Empty;
    public string Building { get; set; } = string.Empty;
    public int AreaId { get; set; }
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
    public string Logo { get; set; } = string.Empty;
    public string About { get; set; } = string.Empty;
      public DateTime CreatedAt { get; set; }
        public int? CreateBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? UpdateBy { get; set; }
}

