﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetDevelopers
    {
        public int RecordsTotal { get; set; }
    public int RecordsFiltered { get; set; }
    public int TotalPages { get; set; }
    [Key]
       public int DeveloperId { get; set; }
        public string DeveloperName { get; set; } = string.Empty;
        public string DeveloperLogo { get; set; } = string.Empty;
        public bool IsActive { get; set; }
}

