﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

    public class GetAreas
    {
        public int RecordsTotal { get; set; }       // Total number of records
        public int RecordsFiltered { get; set; }    // Filtered number of records
        public int TotalPages { get; set; }         // Total number of pages
        [Key]
        public int AreaId { get; set; }
        public int CityId { get; set; }
        public string AreaName { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public int CreateBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int? UpdateBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
}

