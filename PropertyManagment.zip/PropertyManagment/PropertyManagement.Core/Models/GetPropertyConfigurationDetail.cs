﻿
using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;
public class GetPropertyConfigurationDetail
{
    public int RecordsTotal { get; set; }
    public int RecordsFiltered { get; set; }
    public int TotalPages { get; set; }
    [Key]
    public int ConfigDetailId { get; set; }
    public int ConfigMasterId { get; set; }
    public string? Value { get; set; }
    public string? SecondValue { get; set; }
    public string? ImageUrl { get; set; }
    public bool IsActive { get; set; }
    public int? CreateBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public int? UpdateBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

