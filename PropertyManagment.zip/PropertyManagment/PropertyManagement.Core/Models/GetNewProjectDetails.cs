﻿

using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

public class GetNewProjectDetails
{
    [Key]
    public Guid Id { get; set; }
    public int ProjectId { get; set; }
    public int NewProjectMediaId { get; set; }
    public string? ProjectStatus { get; set; }
    public string? ShortDescription { get; set; }
    public string? LongDescription { get; set; } 
    public string? LaunchPrice { get; set; } 
    public DateTime? DeliveryDate { get; set; }
    public DateTime? SalesStart { get; set; }
    public string? Location { get; set; }
    public int? NumberOfBuildings { get; set; }
    public string? PropertyTypes { get; set; }
    public decimal GovFee { get; set; }
    public int DeveloperId { get; set; } 
    public string? DeveloperName { get; set; }
    public string? DeveloperLogo { get; set; }
    public string MediaType { get; set; } = string.Empty;
    public string MediaUrl { get; set; } = string.Empty;
    public string MediaDescription { get; set; } = string.Empty;
    public string MediaMenu { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
}


public class GetProjectPaymentPLan
{
    [Key]
    public int Id { get; set; }
    public string PaymentPlanName { get; set; } = string.Empty;
    public string PlanDescription { get; set; } = string.Empty;
    public string? PlanSubDescription { get; set; }
    public int PlanPercentage { get; set; }
}

public class GetProjectTimeline
{
    [Key]
    public int Id { get; set; }
    public DateTime? Date { get; set; }
    public string Title { get; set; } = string.Empty;
}

public class GetProjectUnit
{
    [Key]
    public int ProjectUnitId { get; set; }
    public string? PropertyType { get; set; }
    public string? BedType { get; set; }
    public string? LayoutType { get; set; }
    public string? Price { get; set; }
    public int Sqft { get; set; }
    public string? FloorPlanUrl { get; set; }
}

