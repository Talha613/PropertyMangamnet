﻿using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Core.Models;

public class GetAgentsList
{
    [Key] public int UserId { get; set; }
    public string AgentName { get; set; } = String.Empty;
    public string AgentEmail { get; set; } = String.Empty;
    public decimal Experience { get; set; }
    public string ProfilePicture { get; set; } = String.Empty;
    public string Phone { get; set; } = String.Empty;
    public string WhatsApp { get; set; } = String.Empty;
    public int RealEstateBrokerId { get; set; }
    public int TotalRecords { get; set; }
    public int TotalPages { get; set; }

}

