﻿

namespace PropertyManagement.Core.DTOs.Shared;
public static class ClaimTypeDto
{
    public const string Id = "ID";
}

