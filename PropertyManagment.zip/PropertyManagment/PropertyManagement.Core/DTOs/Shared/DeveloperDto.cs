﻿

namespace PropertyManagement.Core.DTOs.Shared;
public class DeveloperDto
{
    public int DeveloperId { get; set; }
    public string? DeveloperName { get; set; }
    public string? DeveloperLogo { get; set; }
}

