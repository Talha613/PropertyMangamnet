﻿using Newtonsoft.Json.Linq;

namespace PropertyManagement.Business.Services.External;

public interface IVerifyGoogleAccessTokenService
{
    Task<(string Email, string Name)> GetUserInfoGoogleAsync(string accessToken);
}

public class VerifyGoogleAccessTokenService : IVerifyGoogleAccessTokenService
{
    private readonly HttpClient _httpClient;

    public VerifyGoogleAccessTokenService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<(string Email, string Name)> GetUserInfoGoogleAsync(string accessToken)
    {
        if (string.IsNullOrEmpty(accessToken))
        {
            throw new ArgumentException("Access token must not be null or empty.", nameof(accessToken));
        }

        var requestUri = $"https://www.googleapis.com/oauth2/v1/userinfo?access_token={accessToken}";

        try
        {
            HttpResponseMessage response = await _httpClient.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to get user info. Status code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
            }

            string responseContent = await response.Content.ReadAsStringAsync();
            var jsonResponse = JObject.Parse(responseContent);

            string? email = jsonResponse["email"]?.ToString();
            string? name = jsonResponse["name"]?.ToString();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(name))
            {
                throw new Exception("Invalid user info received from Google API.");
            }

            return (Email: email, Name: name);
        }
        catch (Exception ex)
        {
            throw new Exception("An error occurred while verifying the Google access token.", ex);
        }
    }
}