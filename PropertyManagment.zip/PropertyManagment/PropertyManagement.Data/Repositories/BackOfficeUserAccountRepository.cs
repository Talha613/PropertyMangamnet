﻿
using PropertyManagement.Core.DTOs;

namespace PropertyManagement.Data.Repositories;

public interface IBackOfficeUserAccountRepository
{
    Task<DatabaseResponse> UpdateBackOfficeUserPassword(string email, string password);
    Task<DatabaseResponse> BackOfficeUserLogin(string email, string password);

}
public class BackOfficeUserAccountRepository : IBackOfficeUserAccountRepository
{
    private readonly IGenericRepository _genericRepository;
    public BackOfficeUserAccountRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> UpdateBackOfficeUserPassword(string email, string password)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"Email",email},
            {"NewPassword",password},
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("UpdateBackOfficeUserPassword", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> BackOfficeUserLogin(string email, string password)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"Email",email},
            {"Password",password}
        };
        
        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("BackOfficeUserLogin", parameters);
        return result.Single();
    }
}

