﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;

namespace PropertyManagement.Data.Repositories;

public interface IPropertyConfigurationRepository
{
    Task<DatabaseResponse> InsertUpdatePropertyConfigurationDetails(int detailId, int masterId, string value, string? secondValue, string? imageUrl, int by);

    Task<List<GetPropertyConfigurationDetail>> GetPropertyConfigurationDetail(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);
    
}

public class PropertyConfigurationRepository : IPropertyConfigurationRepository
{
    private readonly IGenericRepository _genericRepository;

    public PropertyConfigurationRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }



    public async Task<DatabaseResponse> InsertUpdatePropertyConfigurationDetails(int detailId, int masterId, string value, string? secondValue,
        string? imageUrl, int by)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ConfigDetailID", detailId },
            { "ConfigMasterID", masterId },
            { "Value", value },
            { "SecondValue", secondValue },
            { "ImageUrl", imageUrl },
            { "CreateBy", by },
            { "UpdateBy", by },
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdatePropertyConfigurationDetails", parameters);
        return result.Single();
    }

    public async Task<List<GetPropertyConfigurationDetail>> GetPropertyConfigurationDetail(int pageNumber, int pageSize, string? search, int orderColumnIndex,
        string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetPropertyConfigurationDetail>("GetPropertyConfigurationDetail", parameters);
        return result;
    }
}