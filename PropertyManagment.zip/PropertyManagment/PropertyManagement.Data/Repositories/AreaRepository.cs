﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;


namespace PropertyManagement.Data.Repositories;
public interface IAreaRepository
{
    Task<DatabaseResponse> InsertUpdateArea(int areaId, int cityId, string areaName, string postalCode, bool isActive, int createBy, int? updateBy = null);
    Task<List<GetAreas>> GetAreas(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);
}

public class AreaRepository : IAreaRepository
{
    private readonly IGenericRepository _genericRepository;
    public AreaRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> InsertUpdateArea(int areaId, int cityId, string areaName, string postalCode, bool isActive, int createBy, int? updateBy = null)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "AreaID", areaId },
            { "CityID", cityId },
            { "AreaName", areaName },
            { "PostalCode", postalCode }, 
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy },
        };


        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateArea", parameters);
        return result.Single();
    }

    public async Task<List<GetAreas>> GetAreas(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetAreas>("GetAreas", parameters);
        return result;
    }
}