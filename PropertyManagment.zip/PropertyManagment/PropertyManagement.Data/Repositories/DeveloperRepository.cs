﻿using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;

namespace PropertyManagement.Data.Repositories;

public interface IDeveloperRepository
{
    Task<DatabaseResponse> InsertUpdateDeveloper(int developerId, string developerName, string logo,bool isActive);

      Task<List<GetDevelopers>> GetDevelopers(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);

}

public class DeveloperRepository : IDeveloperRepository
{
    private readonly IGenericRepository _genericRepository;

    public DeveloperRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }



    public async Task<DatabaseResponse> InsertUpdateDeveloper(int developerId, string developerName, string logo, bool isActive)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "DeveloperID", developerId },
            { "DeveloperName", developerName },
            { "DeveloperLogo", logo },
            { "IsActive", isActive }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateDeveloper", parameters);
        return result.Single();
    }

    public async Task<List<GetDevelopers>> GetDevelopers(int pageNumber, int pageSize, string? search, int orderColumnIndex,
        string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetDevelopers>("GetDevelopers", parameters);
        return result;
    }


}