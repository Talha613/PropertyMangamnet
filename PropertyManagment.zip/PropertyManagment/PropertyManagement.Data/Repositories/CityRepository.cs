﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;


namespace PropertyManagement.Data.Repositories;
public interface ICityRepository
{
    Task<DatabaseResponse> InsertUpdateCity(int cityId, int countryId, string cityName, bool isActive, int createBy, int updateBy);
    Task<List<GetCities>> GetCities(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);

}

public class CityRepository : ICityRepository
{
    private readonly IGenericRepository _genericRepository;
    public CityRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> InsertUpdateCity(int cityId, int countryId, string cityName, bool isActive, int createBy, int updateBy)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "CityID", cityId },
            { "CountryID", countryId },
            { "CityName", cityName },
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy },


        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateCity", parameters);
        return result.Single();
    }

    public async Task<List<GetCities>> GetCities(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetCities>("GetCities", parameters);
        return result;
    }
}