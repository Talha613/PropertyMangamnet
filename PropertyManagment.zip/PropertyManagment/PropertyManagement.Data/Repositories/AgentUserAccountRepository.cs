﻿
using PropertyManagement.Core.DTOs;
namespace PropertyManagement.Data.Repositories;

public interface IAgentUserAccountRepository
{
    Task<DatabaseResponse> UpdateAgentUserPassword(string email, string password);
    Task<DatabaseResponse> AgentUserLogin(string email, string password);

}
public class AgentUserAccountRepository : IAgentUserAccountRepository
{
    private readonly IGenericRepository _genericRepository;
    public AgentUserAccountRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> UpdateAgentUserPassword(string email, string password)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"Email",email},
            {"NewPassword",password},
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("AgentUserUpdatePassword", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> AgentUserLogin(string email, string password)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"Email",email},
            {"Password",password}
        };
        
        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("AgentUserLogin", parameters);
        return result.Single();
    }
}

