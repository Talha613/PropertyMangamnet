﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;


namespace PropertyManagement.Data.Repositories;
public interface ICountryRepository
{
    Task<DatabaseResponse> InsertUpdateCountry(int countryId, string countryName, string countryCode, bool isActive, int createBy, int updateBy);
    Task<List<GetCountries>> GetCountries(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);

}

public class CountryRepository : ICountryRepository
{
    private readonly IGenericRepository _genericRepository;
    public CountryRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> InsertUpdateCountry(int countryId, string countryName, string countryCode, bool isActive, int createBy, int updateBy)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "CountryID", countryId },
            { "CountryName", countryName },
            { "CountryCode", countryCode },
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy },


        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateCountry", parameters);
        return result.Single();
    }

    public async Task<List<GetCountries>> GetCountries(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetCountries>("GetCountries", parameters);
        return result;
    }
}