﻿using PropertyManagement.Core.Models;
namespace PropertyManagement.Data.Repositories;

public interface IFiltersRepository
{
    Task<List<GetFilters>> GetFilters(string language);

}
public class FiltersRepository : IFiltersRepository
{
    private readonly IGenericRepository _genericRepository;
    public FiltersRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }


    public async Task<List<GetFilters>> GetFilters(string language )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "Language", language }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetFilters>("GetFilters", parameters);
        return result;
    }
}

