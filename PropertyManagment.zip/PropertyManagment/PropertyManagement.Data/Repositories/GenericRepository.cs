﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using PropertyManagement.Data.Data;
namespace PropertyManagement.Data.Repositories;

public interface IGenericRepository
{
    Task<List<T>> ExecuteStoredProcedureAsync<T>(string storedProcedureName, Dictionary<string, object?> parameters) where T : class;
}

public class GenericRepository : IGenericRepository
{
    private readonly AppDbContext _dbContext;

    public GenericRepository(AppDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<List<T>> ExecuteStoredProcedureAsync<T>(string storedProcedureName, Dictionary<string, object?> parameters) where T : class
    {
        // Convert parameters to SqlParameter objects
        var sqlParameters = parameters.Select(param =>
        {
            var paramName = param.Key.StartsWith("@") ? param.Key : "@" + param.Key;
            return new SqlParameter(paramName, param.Value ?? DBNull.Value);
        }).ToArray();

        // Build the SQL query with explicit parameter placeholders
        var sqlQuery = $"EXEC [dbo].[{storedProcedureName}] " +
                       string.Join(", ", sqlParameters.Select(p => $"{p.ParameterName}"));

        // Log query and parameters for debugging (optional)
        Console.WriteLine($"SQL Query: {sqlQuery}");
        foreach (var param in sqlParameters)
        {
            Console.WriteLine($"Parameter: {param.ParameterName}, Value: {param.Value}");
        }

        // Execute the query and return results
        return await _dbContext.Set<T>()
            .FromSqlRaw(sqlQuery, sqlParameters)  // Pass SqlParameter array
            .ToListAsync();
    }

}

