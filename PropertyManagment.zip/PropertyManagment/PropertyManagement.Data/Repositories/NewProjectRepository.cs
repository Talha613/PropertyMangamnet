﻿using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;
namespace PropertyManagement.Data.Repositories;

public interface INewProjectRepository
{
    Task<List<GetNewProjects>> GetNewProjects(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms,
        decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea,
        string? amenitiesIDs, int? userId, string language, int pageNumber, int pageSize);
    Task<List<GetNewProjectDetails>> GetNewProjectDetails(int projectId, string language);
    Task<List<GetProjectPaymentPLan>> GetProjectPaymentPLan(int projectId);
    Task<List<GetProjectTimeline>> GetProjectTimeline(int projectId);
    Task<List<GetProjectUnit>> GetProjectUnit(int projectId);
    Task<DatabaseResponse> DeleteNewProject(int projectId);
    Task<List<GetMediaByProjectIdForAdminPanel>> GetMediaByProjectIdForAdminPanel(int projectId);
    Task<List<GetUnitByProjectIdForAdmin>> GetUnitByProjectIdForAdmin(int projectId);

    Task<List<GetProjectTimelineByProjectIdForAdmin>> GetProjectTimelineByProjectIdForAdmin(int projectId);

    Task<DatabaseResponse> InsertUpdateProjectPaymentPlanDetail(
       int projectPaymentPlanDetailId,
       int paymentPlanId,
       string? planDescription,
       decimal planPercentage,
       string? planSubDescription,
       int createBy,
       int? updateBy = null
   );

    Task<DatabaseResponse> InsertUpdatePaymentPlan(
        int paymentPlanId,
        int projectId,
        string paymentPlanName,
        int createBy,
        int? updateBy = null
    );

    Task<DatabaseResponse> InsertUpdateProjectTimeline(int projectTimelineId, int projectId,
        int timeLineConfigId, DateTime? date, int createBy, int? updateBy = null);
    Task<DatabaseResponse> InsertUpdateNewProject(
        int projectId,
        int projectStatus,
        int developerId,
        int areaId,
        string communityName,
        decimal? govFee,
        string? shortDescription,
        string? longDescription,
        decimal? launchPrice,
        DateTime? deliveryDate,
        DateTime? salesStart,
        int? numberOfBuildings,
        int? propertyTypeId,
        int createBy,
        int? updateBy = null
    );

    Task<DatabaseResponse> InsertNewProjectMedia(
       int newProjectId,
       int mediaMenuId,
       string mediaUrl,
       string? mediaDescription,
       string mediaType,
       int createBy,
       int? updateBy = null);

    Task<DatabaseResponse> InsertNewProjectsDetailMap(
        int projectId,
        string configDetailsList,
        string? firstValue,
        string? secondValue,
        int createBy
    );


    Task<DatabaseResponse> InsertUpdateProjectUnit(
        int projectUnitId,
        int projectId,
        int propertyTypeId,
        int bed,
        string? layoutType,
        decimal? price,
        int sqft,
        string? floorPlanUrl,
        int createBy,
        int? updateBy = null);



    Task<List<GetProjects>> GetProjects(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);


}
public class NewProjectRepository : INewProjectRepository
{
    private readonly IGenericRepository _genericRepository;
    public NewProjectRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> InsertNewProjectsDetailMap(
        int projectId,
        string configDetailsList,
        string? firstValue,
        string? secondValue,
        int createBy
    )
    {


        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
            { "ConfigDetailsList", configDetailsList },
            { "FirstValue", firstValue },
            { "SecondValue", secondValue },
            { "CreateBy", createBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertNewProjectsDetailMap", parameters);

        return result.Single();
    }

    public async Task<DatabaseResponse> InsertUpdateProjectTimeline(int projectTimelineId, int projectId, int timeLineConfigId, DateTime? date, int createBy, int? updateBy = null)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectTimelineID", projectTimelineId },
            { "ProjectID", projectId },
            { "TimeLineConfigID", timeLineConfigId },
            { "Date", date },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateProjectTimeline", parameters);
        return result.Single();
    }


    public async Task<List<GetMediaByProjectIdForAdminPanel>> GetMediaByProjectIdForAdminPanel(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetMediaByProjectIdForAdminPanel>("GetMediaByProjectIdForAdminPanel", parameters);
        return result;
    }

    public async Task<List<GetUnitByProjectIdForAdmin>> GetUnitByProjectIdForAdmin(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetUnitByProjectIdForAdmin>("GetUnitByProjectIdForAdmin", parameters);
        return result;
    }

    public async Task<List<GetProjectTimelineByProjectIdForAdmin>> GetProjectTimelineByProjectIdForAdmin(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetProjectTimelineByProjectIdForAdmin>("GetProjectTimelineByProjectIdForAdmin", parameters);
        return result;
    }

    public async Task<DatabaseResponse> InsertUpdateProjectPaymentPlanDetail(
        int projectPaymentPlanDetailId,
        int paymentPlanId,
        string? planDescription,
        decimal planPercentage,
        string? planSubDescription,
        int createBy,
        int? updateBy = null
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectPaymentPlanDetailID", projectPaymentPlanDetailId },
            { "PaymentPlanID", paymentPlanId },
            { "PlanDescription", planDescription },
            { "PlanPercentage", planPercentage },
            { "PlanSubDescription", planSubDescription },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateProjectPaymentPlanDetail", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> InsertNewProjectMedia(
        int newProjectId,
        int mediaMenuId,
        string mediaUrl,
        string? mediaDescription,
        string mediaType,
        int createBy,
        int? updateBy = null
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "NewProjectID", newProjectId },
            { "MediaMenuID", mediaMenuId },
            { "MediaUrl", mediaUrl },
            { "MediaDescription", mediaDescription },
            { "MediaType", mediaType },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertNewProjectMedia", parameters);
        return result.Single();
    }


    public async Task<DatabaseResponse> DeleteNewProject(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("DeleteNewProject", parameters);
        return result.Single();
    }


    public async Task<DatabaseResponse> InsertUpdatePaymentPlan(
        int paymentPlanId,
        int projectId,
        string paymentPlanName,
        int createBy,
        int? updateBy = null
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PaymentPlanID", paymentPlanId },
            { "ProjectID", projectId },
            { "PaymentPlanName", paymentPlanName },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdatePaymentPlan", parameters);
        return result.Single();
    }


    public async Task<DatabaseResponse> InsertUpdateNewProject(
        int projectId,
        int projectStatus,
        int developerId,
        int areaId,
        string communityName,
        decimal? govFee,
        string? shortDescription,
        string? longDescription,
        decimal? launchPrice,
        DateTime? deliveryDate,
        DateTime? salesStart,
        int? numberOfBuildings,
        int? propertyTypeId,
        int createBy,
        int? updateBy = null
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
            { "ProjectStatus", projectStatus },
            { "DeveloperID", developerId },
            { "AreaID", areaId },
            { "CommunityName", communityName },
            { "GovFee", govFee },
            { "ShortDescription", shortDescription },
            { "LongDescription", longDescription },
            { "LaunchPrice", launchPrice },
            { "DeliveryDate", deliveryDate },
            { "SalesStart", salesStart },
            { "NumberOfBuildings", numberOfBuildings },
            { "PropertyTypeID", propertyTypeId },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateNewProject", parameters);
        return result.Single();
    }








    public async Task<List<GetNewProjects>> GetNewProjects(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms, decimal? minPrice,
        decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs, int? userId, string language,
        int pageNumber, int pageSize)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "Search", search },
            { "PropertyTypeID", propertyTypeId },
            { "Bedrooms", bedrooms },
            { "Bathrooms", bathrooms },
            { "MinPrice", minPrice },
            { "MaxPrice", maxPrice },
            { "Keywords", keywords },
            { "MinArea", minArea },
            { "MaxArea", maxArea },
            { "AmenitiesIDs", amenitiesIDs },
            { "UserID", userId },
            { "Language", language}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetNewProjects>("GetNewProjects", parameters);
        return result;
    }

    public async Task<List<GetNewProjectDetails>> GetNewProjectDetails(int projectId, string language)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
            { "Language", language}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetNewProjectDetails>("GetNewProjectDetails", parameters);
        return result;
    }

    public async Task<List<GetProjectPaymentPLan>> GetProjectPaymentPLan(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetProjectPaymentPLan>("GetProjectPaymentPLan", parameters);
        return result;
    }

    public async Task<List<GetProjectTimeline>> GetProjectTimeline(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetProjectTimeline>("GetProjectTimeline", parameters);
        return result;
    }


    public async Task<DatabaseResponse> InsertUpdateProjectUnit(
        int projectUnitId,
        int projectId,
        int propertyTypeId,
        int bed,
        string? layoutType,
        decimal? price,
        int sqft,
        string? floorPlanUrl,
        int createBy,
        int? updateBy = null)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectUnitID", projectUnitId },
            { "ProjectID", projectId },
            { "PropertyTypeID", propertyTypeId },
            { "Bed", bed },
            { "LayoutType", layoutType },
            { "Price", price },
            { "Sqft", sqft },
            { "FloorPlanUrl", floorPlanUrl },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateProjectUnit", parameters);
        return result.Single();
    }

    public async Task<List<GetProjects>> GetProjects(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetProjects>("GetProjects", parameters);
        return result;
    }


    public async Task<List<GetProjectUnit>> GetProjectUnit(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetProjectUnit>("GetProjectUnit", parameters);
        return result;
    }
}

