﻿using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;
namespace PropertyManagement.Data.Repositories;

public interface IBrokerRepository
{
    Task<List<GetEstateBrokersWithAgentCounts>> GetEstateBrokersWithAgentCounts(int pageNumber, int pageSize);
    Task<DatabaseResponse> InsertUpdateRealEstateBroker(int realEstateBrokerId, string name, string orn,
     string office, string building, int areaId, string email, string phone, string? logo, string about,
     int? createBy = null, string? updateBy = null);
    Task<List<GetRealEstateBrokers>> GetRealEstateBrokers(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);
}
public class BrokerRepository : IBrokerRepository
{
    private readonly IGenericRepository _genericRepository;
    public BrokerRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }


    public async Task<List<GetEstateBrokersWithAgentCounts>> GetEstateBrokersWithAgentCounts(int pageNumber, int pageSize)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetEstateBrokersWithAgentCounts>("GetEstateBrokersWithAgentCounts", parameters);
        return result;
    }

    public async Task<DatabaseResponse> InsertUpdateRealEstateBroker(int realEstateBrokerId, string name, string orn, string office, string building,
        int areaId, string email, string phone, string? logo, string about, int? createBy = null, string? updateBy = null)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "RealEstateBrokerID", realEstateBrokerId },
            { "Name", name },
            { "Orn", orn },
            { "Office", office },
            { "Building", building },
            { "AreaID", areaId },
            { "Email", email },
            { "Phone", phone },
            { "Logo", logo },
            { "About", about },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateRealEstateBroker", parameters);
        return result.Single();
    }

    public async Task<List<GetRealEstateBrokers>> GetRealEstateBrokers(int pageNumber, int pageSize, string? search, int orderColumnIndex,
        string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetRealEstateBrokers>("GetRealEstateBrokers", parameters);
        return result;
    }


}

