﻿using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;
namespace PropertyManagement.Data.Repositories;

public interface IAgentRepository
{
    Task<List<GetAgentsList>> GetAgentsList(int? brokerId,int pageNumber, int pageSize);
    Task<DatabaseResponse> InsertUpdateAgentUser(int userId, string name, string email, string? password, int experience, string? profilePicture, string phone, string whatsApp, int realEstateBrokerId, bool isActive, int createBy, string updateBy);

    Task<List<GetAgentUsers>> GetAgentUsers(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);
}
public class AgentRepository : IAgentRepository
{
    private readonly IGenericRepository _genericRepository;
    public AgentRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }


    public async Task<List<GetAgentsList>> GetAgentsList(int? brokerId, int pageNumber, int pageSize)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "BrokerID", brokerId },
            { "PageNumber", pageNumber },
            { "PageSize", pageSize }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetAgentsList>("GetAgentsList", parameters);
        return result;
    }

    public async Task<DatabaseResponse> InsertUpdateAgentUser(int userId, string name, string email, string? password, int experience,
        string? profilePicture, string phone, string whatsApp, int realEstateBrokerId, bool isActive, int createBy,
        string updateBy)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "UserID", userId },
            { "Name", name },
            { "Email", email },
            { "Password", password },
            { "Experience", experience },
            { "ProfilePicture", profilePicture },
            { "Phone", phone },
            { "WhatsApp", whatsApp },
            { "RealEstateBrokerID", realEstateBrokerId },
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateAgentUser", parameters);
        return result.Single();
    }

    public async Task<List<GetAgentUsers>> GetAgentUsers(int pageNumber, int pageSize, string? search, int orderColumnIndex,
        string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetAgentUsers>("GetAgentUsers", parameters);
        return result;
    }


}

