﻿
using PropertyManagement.Core.DTOs;

namespace PropertyManagement.Data.Repositories;

public interface IUserAccountRepository
{
    Task<DatabaseResponse> RegisterUser(string firstName, string lastName, string email, string password);
    Task<DatabaseResponse> UpdateUserPassword(string email, string password);
    Task<DatabaseResponse> UserLogin(string email, string password,string accessToken);

}
public class UserAccountRepository : IUserAccountRepository
{
    private readonly IGenericRepository _genericRepository;
    public UserAccountRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }
    public async Task<DatabaseResponse> RegisterUser(string firstName, string lastName, string email, string password)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"FirstName",firstName},
            {"LastName",lastName},
            {"Email",email},
            {"Password",password},

        };
        
        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("RegisterUser", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> UpdateUserPassword(string email, string password)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"Email",email},
            {"NewPassword",password},
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("UpdateUserPassword", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> UserLogin(string email, string password, string accessToken)
    {
        var parameters = new Dictionary<string, object?>
        {
            {"Email",email},
            {"Password",password},
            {"AccessToken",accessToken}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("UserLogin", parameters);
        return result.Single();
    }
}

