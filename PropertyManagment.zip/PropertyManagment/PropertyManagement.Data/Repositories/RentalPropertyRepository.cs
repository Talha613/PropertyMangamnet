﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;
namespace PropertyManagement.Data.Repositories;

public interface IRentalPropertyRepository
{
    Task<List<GetRentalProperties>> GetRentalProperties(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms,
        decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea,
        string? amenitiesIDs, int? userId, string language, int pageNumber, int pageSize);

    Task<List<GetRentalPropertiesAssociatedCounts>> GetRentalPropertiesAssociatedCounts(string? search,
         int? propertyTypeId, int? bedrooms, int? bathrooms,
         decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs,
         string language);

    Task<List<GetRentalPropertyDetails>> GetRentalPropertyDetails(int rentalPropertyId, string language);

    Task<List<GetRentalPropertyCosts>> GetRentalPropertyCosts(int rentalPropertyId);


    Task<DatabaseResponse> InsertUpdateRentalProperty(
        int rentalPropertyId,
        string shortDescription,
        string longDescription,
        string buildingName,
        int areaId,
        decimal? longitude,
        decimal? latitude,
        int squareFeet,
        int squareMeter,
        int bedrooms,
        bool haveMadeRoom,
        int bathrooms,
        int propertyTypeId,
        DateTime? availableFrom,
        bool isActive,
        int createBy,
        int? updateBy = null
    );

    Task<DatabaseResponse> InsertRentalPropertyMedia(
        int rentalPropertyId,
        int mediaMenuId,
        string mediaUrl,
        string mediaType,
        int createBy
    );

    Task<DatabaseResponse> InsertRentalPropertyDetailMap(
       int rentalProjectId,
       string configDetailsList,
       string? firstValue,
       string? secondValue,
       int createBy
   );

    Task<DatabaseResponse>  InsertRentalPropertyCosts(
        int rentPropertyId,
        decimal annualRent,
        decimal agencyFeePercentage,
        decimal agencyFeeVatPercentage,
        decimal securityDeposit,
        decimal dewADeposit,
        decimal ejariFee,
        int createdBy);

}
public class RentalPropertyRepository : IRentalPropertyRepository
{
    private readonly IGenericRepository _genericRepository;
    public RentalPropertyRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }


    public async Task<List<GetRentalProperties>> GetRentalProperties(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms, decimal? minPrice,
        decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs, int? userId, string language,
        int pageNumber, int pageSize)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "Search", search },
            { "PropertyTypeID", propertyTypeId },
            { "Bedrooms", bedrooms },
            { "Bathrooms", bathrooms },
            { "MinPrice", minPrice },
            { "MaxPrice", maxPrice },
            { "Keywords", keywords },
            { "MinArea", minArea },
            { "MaxArea", maxArea },
            { "AmenitiesIDs", amenitiesIDs },
            { "UserID", userId },
            { "Language", language},
            { "PageNumber", pageNumber },
            { "PageSize", pageSize }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetRentalProperties>("GetRentalProperties", parameters);
        return result;
    }

    public async Task<List<GetRentalPropertiesAssociatedCounts>> GetRentalPropertiesAssociatedCounts(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms,
        decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs,
        string language)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "Search", search },
            { "PropertyTypeID", propertyTypeId },
            { "Bedrooms", bedrooms },
            { "Bathrooms", bathrooms },
            { "MinPrice", minPrice },
            { "MaxPrice", maxPrice },
            { "Keywords", keywords },
            { "MinArea", minArea },
            { "MaxArea", maxArea },
            { "AmenitiesIDs", amenitiesIDs },
            { "Language", language}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetRentalPropertiesAssociatedCounts>("GetBuyPropertiesAssociatedCounts", parameters);
        return result;
    }

    public async Task<List<GetRentalPropertyDetails>> GetRentalPropertyDetails(int rentalPropertyId, string language)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "RentalPropertyID", rentalPropertyId },
            { "Language", language}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetRentalPropertyDetails>("GetRentalPropertyDetails", parameters);
        return result;
    }

    public async Task<List<GetRentalPropertyCosts>> GetRentalPropertyCosts(int rentalPropertyId)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "RentalPropertyID", rentalPropertyId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetRentalPropertyCosts>("GetRentalPropertyCosts", parameters);
        return result;
    }


    public async Task<DatabaseResponse> InsertUpdateRentalProperty(
        int rentalPropertyId,
        string shortDescription,
        string longDescription,
        string buildingName,
        int areaId,
        decimal? longitude,
        decimal? latitude,
        int squareFeet,
        int squareMeter,
        int bedrooms,
        bool haveMadeRoom,
        int bathrooms,
        int propertyTypeId,
        DateTime? availableFrom,
        bool isActive,
        int createBy,
        int? updateBy = null
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "RentalPropertyID", rentalPropertyId },
            { "ShortDescription", shortDescription },
            { "LongDescription", longDescription },
            { "BuildingName", buildingName },
            { "AreaID", areaId },
            { "Longitude", longitude },
            { "Latitude", latitude },
            { "SquareFeet", squareFeet },
            { "SquareMeter", squareMeter },
            { "BedRooms", bedrooms },
            { "HaveMadeRoom", haveMadeRoom },
            { "Bathrooms", bathrooms },
            { "PropertyTypeID", propertyTypeId },
            { "AvailableFrom", availableFrom },
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateRentalProperty", parameters);
        return result.Single();
    }



    public async Task<DatabaseResponse> InsertRentalPropertyMedia(
        int rentalPropertyId,
        int mediaMenuId,
        string? mediaDescription,
        string mediaType,
        int createBy
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "RentalPropertyID", rentalPropertyId },
            { "MediaMenuID", mediaMenuId },
            { "MediaDescription", mediaDescription },
            { "MediaType", mediaType },
            { "CreateBy", createBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertRentalPropertyMedia", parameters);
        return result.Single();
    }


    public async Task<DatabaseResponse> InsertRentalPropertyDetailMap(
        int rentalProjectId,
        string configDetailsList,
        string? firstValue,
        string? secondValue,
        int createBy
    )
    {


        var parameters = new Dictionary<string, object?>
        {
            { "RentalPropertyID", rentalProjectId },
            { "ConfigDetailsList", configDetailsList },
            { "FirstValue", firstValue },
            { "SecondValue", secondValue },
            { "CreateBy", createBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertRentalPropertyDetailMap", parameters);

        return result.Single();
    }



    public async Task<DatabaseResponse> InsertRentalPropertyCosts(
        int rentPropertyId,
        decimal annualRent,
        decimal agencyFeePercentage,
        decimal agencyFeeVatPercentage,
        decimal securityDeposit,
        decimal dewADeposit,
        decimal ejariFee,
        int createdBy)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "RentPropertyID", rentPropertyId },
            { "AnnualRent", annualRent },
            { "AgencyFeePercentage", agencyFeePercentage },
            { "AgencyFeeVATPercentage", agencyFeeVatPercentage },
            { "SecurityDeposit", securityDeposit },
            { "DEWADeposit", dewADeposit },
            { "EjariFee", ejariFee },
            { "CreatedBy", createdBy }
        };

        // Execute the stored procedure to insert the rental property costs
        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertRentalPropertyCosts", parameters);

        // Return the response, assuming 'result' contains the expected data
        return result.Single();
    }





}

