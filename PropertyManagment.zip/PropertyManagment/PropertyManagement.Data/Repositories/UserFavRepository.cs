﻿using PropertyManagement.Core.DTOs;
namespace PropertyManagement.Data.Repositories;

public interface IUserFavRepository
{
    Task<DatabaseResponse> InsertBuyPropertyUserFav(int buyPropertyId, int userId);
    Task<DatabaseResponse> RemoveBuyPropertyUserFav(int id);

    Task<DatabaseResponse> InsertRentPropertyUserFav(int rentPropertyId, int userId);
    Task<DatabaseResponse> RemoveRentPropertyUserFav(int id);

    Task<DatabaseResponse> InsertNewProjectUserFav(int projectId, int userId);
    Task<DatabaseResponse> RemoveNewProjectUserFav(int id);


}
public class UserFavRepository : IUserFavRepository
{
    private readonly IGenericRepository _genericRepository;
    public UserFavRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }



    public async Task<DatabaseResponse> InsertBuyPropertyUserFav(int buyPropertyId, int userId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId },
            { "UserID", userId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertBuyPropertyUserFav", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> RemoveBuyPropertyUserFav(int id)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ID", id }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("RemoveBuyPropertyUserFav", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> InsertRentPropertyUserFav(int rentPropertyId, int userId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "RentPropertyID", rentPropertyId },
            { "UserID", userId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertRentPropertyUserFav", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> RemoveRentPropertyUserFav(int id)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ID", id }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("RemoveRentPropertyUserFav", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> InsertNewProjectUserFav(int projectId, int userId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ProjectID", projectId },
            { "UserID", userId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertNewProjectUserFav", parameters);
        return result.Single();
    }

    public async Task<DatabaseResponse> RemoveNewProjectUserFav(int id)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "ID", id }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("RemoveNewProjectUserFav", parameters);
        return result.Single();
    }
}

