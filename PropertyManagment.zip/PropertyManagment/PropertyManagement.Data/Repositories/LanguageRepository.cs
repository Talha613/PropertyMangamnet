﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;


namespace PropertyManagement.Data.Repositories;
public interface ILanguageRepository
{
    Task<DatabaseResponse> InsertUpdateLanguage(int languageId, string languageCode, string languageName, bool isActive, int createBy, int? updateBy = null);
    Task<List<GetLanguages>> GetLanguages(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection);
}

public class LanguageRepository : ILanguageRepository
{
    private readonly IGenericRepository _genericRepository;
    public LanguageRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }

    public async Task<DatabaseResponse> InsertUpdateLanguage(int languageId, string languageCode, string languageName, bool isActive, int createBy, int? updateBy = null)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "LanguageID", languageId },        
            { "LanguageCode", languageCode },    
            { "LanguageName", languageName },   
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy },        
        };


        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateLanguage", parameters);
        return result.Single();
    }

    public async Task<List<GetLanguages>> GetLanguages(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetLanguages>("GetLanguages", parameters);
        return result;
    }
}