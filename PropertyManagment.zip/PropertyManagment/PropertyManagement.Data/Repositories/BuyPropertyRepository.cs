﻿using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;
namespace PropertyManagement.Data.Repositories;

public interface IBuyPropertyRepository
{
    Task<List<GetBuyProperties>> GetBuyProperties(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms,
        decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea,
        string? amenitiesIDs, int? userId, string language, int pageNumber, int pageSize);

    Task<List<GetBuyPropertiesAssociatedCounts>> GetBuyPropertiesAssociatedCounts(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms,
        decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea,
        string? amenitiesIDs, string language);


    Task<List<GetBuyPropertyDetails>> GetBuyPropertyDetails(int buyPropertyId, string language);
    Task<List<GetBuyPropertyPurchaseCostsCash>> GetBuyPropertyPurchaseCostsCash(int buyPropertyId);

    Task<List<GetBuyPropertyPurchaseMortgageCosts>> GetBuyPropertyPurchaseMortgageCosts(int buyPropertyId);

    Task<List<GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel>> GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel(int buyPropertyId);


    Task<List<GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel>>
        GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel(int buyPropertyId);

    Task<DatabaseResponse> InsertPropertyPurchaseCostsCash(
        int buyPropertyId,
        decimal purchasePrice,
        decimal landDeptFeePercentage,
        decimal agencyFeePercentage,
        decimal agencyFeeVatPercentage,
        decimal trusteeFee,
        decimal conveyancerFee,
        int createdBy);



    Task<DatabaseResponse> InsertBuyPropertyDetailMap(
      int buyPropertyId,
      string configDetailsList,
      string? firstValue,
      string? secondValue,
      int createBy
  );

    Task<DatabaseResponse> InsertPropertyPurchaseMortgageCosts(
           int buyPropertyId,
           decimal purchasePrice,
           decimal downPayment,
           decimal landDeptFee,
           decimal trusteeFee,
           decimal mortgageRegistrationFee,
           decimal agencyFee,
           decimal bankArrangementFee,
           decimal valuationFee,
           decimal amountRequiredUpfront,
           int createdBy
       );

    Task<DatabaseResponse> InsertUpdateBuyProperty(
        int buyPropertyId,
        string shortDescription,
        string longDescription,
        string buildingName,
        int areaId,
        decimal? longitude,
        decimal? latitude,
        int squareFeet,
        int squareMeter,
        int bedrooms,
        bool haveMadeRoom,
        int bathrooms,
        int propertyTypeId,
        bool isActive,
        int createBy,
        int? updateBy = null
    );


    Task<DatabaseResponse> InsertBuyPropertyMedia(
        int rentalPropertyId,
        int mediaMenuId,
        string? mediaDescription,
        string mediaType,
        int createBy
    );


    Task<List<GetBuyPropertiesForPanel>> GetBuyPropertiesForPanel(int pageNumber, int pageSize,
     string? search, int orderColumnIndex, string orderDirection);


    Task<List<GetMediaByBuyPropertyIdForAdminPanel>> GetMediaByBuyPropertyIdForAdminPanel(int projectId);


}
public class BuyPropertyRepository : IBuyPropertyRepository
{
    private readonly IGenericRepository _genericRepository;
    public BuyPropertyRepository(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }



    public async Task<List<GetMediaByBuyPropertyIdForAdminPanel>> GetMediaByBuyPropertyIdForAdminPanel(int projectId)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PropertyID", projectId },
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetMediaByBuyPropertyIdForAdminPanel>("GetMediaByBuyPropertyIdForAdminPanel", parameters);
        return result;
    }


    public async Task<DatabaseResponse> InsertBuyPropertyMedia(
        int rentalPropertyId,
        int mediaMenuId,
        string? mediaDescription,
        string mediaType,
        int createBy
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", rentalPropertyId },
            { "MediaMenuID", mediaMenuId },
            { "MediaDescription", mediaDescription },
            { "MediaType", mediaType },
            { "CreateBy", createBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertBuyPropertyMedia", parameters);
        return result.Single();
    }


    public async Task<DatabaseResponse> InsertPropertyPurchaseCostsCash(
        int buyPropertyId,
        decimal purchasePrice,
        decimal landDeptFeePercentage,
        decimal agencyFeePercentage,
        decimal agencyFeeVatPercentage,
        decimal trusteeFee,
        decimal conveyancerFee,
        int createdBy)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId },
            { "PurchasePrice", purchasePrice },
            { "LandDeptFeePercentage", landDeptFeePercentage },
            { "AgencyFeePercentage", agencyFeePercentage },
            { "AgencyFeeVATPercentage", agencyFeeVatPercentage },
            { "TrusteeFee", trusteeFee },
            { "ConveyancerFee", conveyancerFee },
            { "CreatedBy", createdBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertPropertyPurchaseCostsCash", parameters);
        return result.Single();
    }


    public async Task<DatabaseResponse> InsertBuyPropertyDetailMap(
        int buyPropertyId,
        string configDetailsList,
        string? firstValue,
        string? secondValue,
        int createBy
    )
    {


        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId },
            { "ConfigDetailsList", configDetailsList },
            { "FirstValue", firstValue },
            { "SecondValue", secondValue },
            { "CreateBy", createBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertBuyPropertyDetailMap", parameters);

        return result.Single();
    }


    public async Task<DatabaseResponse> InsertUpdateBuyProperty(
        int buyPropertyId,
        string shortDescription,
        string longDescription,
        string buildingName,
        int areaId,
        decimal? longitude,
        decimal? latitude,
        int squareFeet,
        int squareMeter,
        int bedrooms,
        bool haveMadeRoom,
        int bathrooms,
        int propertyTypeId,
        bool isActive,
        int createBy,
        int? updateBy = null
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId },
            { "ShortDescription", shortDescription },
            { "LongDescription", longDescription },
            { "BuildingName", buildingName },
            { "AreaID", areaId },
            { "Longitude", longitude },
            { "Latitude", latitude },
            { "SquareFeet", squareFeet },
            { "SquareMeter", squareMeter },
            { "BedRooms", bedrooms },
            { "HaveMadeRoom", haveMadeRoom },
            { "Bathrooms", bathrooms },
            { "PropertyTypeID", propertyTypeId },
            { "IsActive", isActive },
            { "CreateBy", createBy },
            { "UpdateBy", updateBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertUpdateBuyProperty", parameters);
        return result.Single();
    }


    public async Task<List<GetBuyProperties>> GetBuyProperties(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms, decimal? minPrice,
        decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs, int? userId, string language,
        int pageNumber, int pageSize)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "Search", search },
            { "PropertyTypeID", propertyTypeId },
            { "Bedrooms", bedrooms },
            { "Bathrooms", bathrooms },
            { "MinPrice", minPrice },
            { "MaxPrice", maxPrice },
            { "Keywords", keywords },
            { "MinArea", minArea },
            { "MaxArea", maxArea },
            { "AmenitiesIDs", amenitiesIDs },
            { "UserID", userId },
            { "Language", language},
            { "PageNumber", pageNumber },
            { "PageSize", pageSize }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyProperties>("GetBuyProperties", parameters);
        return result;
    }


    public async Task<List<GetBuyProperties>> InsertPropertyPurchaseMortgageCosts(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms, decimal? minPrice,
        decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs, int? userId, string language,
        int pageNumber, int pageSize)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", search },
            { "PurchasePrice", propertyTypeId },
            { "DownPayment", bedrooms },
            { "LandDeptFee", bathrooms },

            { "TrusteeFee", minPrice },
            { "MortgageRegistrationFee", maxPrice },
            { "AgencyFee", keywords },
            { "BankArrangementFee", minArea },
            { "MaxArea", maxArea },
            { "ValuationFee", amenitiesIDs },
            { "CreatedBy", userId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyProperties>("InsertPropertyPurchaseMortgageCosts", parameters);
        return result;
    }


    public async Task<DatabaseResponse> InsertPropertyPurchaseMortgageCosts(
        int buyPropertyId,
        decimal purchasePrice,
        decimal downPayment,
        decimal landDeptFee,
        decimal trusteeFee,
        decimal mortgageRegistrationFee,
        decimal agencyFee,
        decimal bankArrangementFee,
        decimal valuationFee,
        decimal amountRequiredUpfront,
        int createdBy
    )
    {
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId },
            { "PurchasePrice", purchasePrice },
            { "DownPayment", downPayment },
            { "LandDeptFee", landDeptFee },
            { "TrusteeFee", trusteeFee },
            { "MortgageRegistrationFee", mortgageRegistrationFee },
            { "AgencyFee", agencyFee },
            { "BankArrangementFee", bankArrangementFee },
            { "ValuationFee", valuationFee },
            { "AmountRequiredUpfront", amountRequiredUpfront },
            { "CreatedBy", createdBy }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("InsertPropertyPurchaseMortgageCosts", parameters);
        return result.Single();
    }



    public async Task<List<GetBuyPropertiesAssociatedCounts>> GetBuyPropertiesAssociatedCounts(string? search, int? propertyTypeId, int? bedrooms, int? bathrooms,
        decimal? minPrice, decimal? maxPrice, string? keywords, int? minArea, int? maxArea, string? amenitiesIDs,
        string language)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "Search", search },
            { "PropertyTypeID", propertyTypeId },
            { "Bedrooms", bedrooms },
            { "Bathrooms", bathrooms },
            { "MinPrice", minPrice },
            { "MaxPrice", maxPrice },
            { "Keywords", keywords },
            { "MinArea", minArea },
            { "MaxArea", maxArea },
            { "AmenitiesIDs", amenitiesIDs },
            { "Language", language}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyPropertiesAssociatedCounts>("GetBuyPropertiesAssociatedCounts", parameters);
        return result;
    }

    public async Task<List<GetBuyPropertyDetails>> GetBuyPropertyDetails(int buyPropertyId, string language)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId },
            { "Language", language}
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyPropertyDetails>("GetBuyPropertyDetails", parameters);
        return result;
    }

    public async Task<List<GetBuyPropertyPurchaseCostsCash>> GetBuyPropertyPurchaseCostsCash(int buyPropertyId)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyPropertyPurchaseCostsCash>("GetBuyPropertyPurchaseCostsCash", parameters);
        return result;
    }


    public async Task<List<GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel>> GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel(int buyPropertyId)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel>("GetBuyPropertyPurchaseCostsCash", parameters);
        return result;
    }

    public async Task<List<GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel>> GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel(int buyPropertyId)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel>("GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel", parameters);
        return result;
    }

    public async Task<List<GetBuyPropertyPurchaseMortgageCosts>> GetBuyPropertyPurchaseMortgageCosts(int buyPropertyId)
    {
        // Prepare the parameters for the stored procedure
        var parameters = new Dictionary<string, object?>
        {
            { "BuyPropertyID", buyPropertyId }
        };
        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyPropertyPurchaseMortgageCosts>("GetBuyPropertyPurchaseMortgageCosts", parameters);
        return result;
    }

    public async Task<List<GetBuyPropertiesForPanel>> GetBuyPropertiesForPanel(int pageNumber, int pageSize, string? search, int orderColumnIndex, string orderDirection)
    {
        var parameters = new Dictionary<string, object?>
        {
            { "PageNumber", pageNumber },
            { "PageSize", pageSize },
            { "Search", search },
            { "OrderColumnIndex", orderColumnIndex },
            { "OrderDirection", orderDirection }
        };

        var result = await _genericRepository.ExecuteStoredProcedureAsync<GetBuyPropertiesForPanel> ("GetBuyPropertiesForPanel", parameters);
        return result;
    }



}

