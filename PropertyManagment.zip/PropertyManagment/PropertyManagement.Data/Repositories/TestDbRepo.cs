﻿
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;

namespace PropertyManagement.Data.Repositories;
public interface ITestDbRepo
{
   Task<DatabaseResponse> GetPropertiesAsync();
}

public class TestDbRepo : ITestDbRepo
{
    private readonly IGenericRepository _genericRepository;
    public TestDbRepo(IGenericRepository genericRepository)
    {
        _genericRepository = genericRepository;
    }
    public async Task<DatabaseResponse> GetPropertiesAsync()
    {

        var parameters = new Dictionary<string, object>
        {
        }; 

        var result = await _genericRepository.ExecuteStoredProcedureAsync<DatabaseResponse>("GetPropertiesByPriceRange", parameters);
        return result.Single();

    }
}

