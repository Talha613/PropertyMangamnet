﻿using Microsoft.EntityFrameworkCore;
using PropertyManagement.Core.DTOs;
using PropertyManagement.Core.Models;

namespace PropertyManagement.Data.Data;

public class AppDbContext : DbContext
{
    // No need to pass DbSet to the constructor
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<DatabaseResponse>? DatabaseResponses { get; set; }
    public DbSet<GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel>? GetPropertyPurchaseCostsCashByBuyPropertyIdForPanel { get; set; }


    public DbSet<GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel>? GetPropertyPurchaseMortgageCostsByBuyPropertyIdForPanel { get; set; }

    

    public DbSet<GetBuyPropertiesForPanel>? GetBuyPropertiesForPanel { get; set; }
    public DbSet<GetBuyProperties>? GetBuyProperties { get; set; }
    public DbSet<GetBuyPropertyDetails>? GetBuyPropertyDetails { get; set; }
    public DbSet<GetProjectPaymentPLan>? GetProjectPaymentPLan { get; set; }
    public DbSet<GetProjectTimeline>? GetProjectTimeline { get; set; }
    public DbSet<GetProjectUnit>? GetProjectUnit { get; set; }
    public DbSet<GetLanguages>? GetLanguages { get; set; }
    public DbSet<GetAreas>? GetAreas { get; set; }
    public DbSet<GetCountries>? GetCountries { get; set; }
    public DbSet<GetCities>? GetCities { get; set; }
    public DbSet<GetProjects>? GetProjects { get; set; }
    public DbSet<GetMediaByProjectIdForAdminPanel>? NewProjectMediaByIdDto { get; set; }

    public DbSet<GetUnitByProjectIdForAdmin>? GetUnitByProjectIdForAdmin { get; set; }
    public DbSet<GetProjectTimelineByProjectIdForAdmin>? GetProjectTimelineByProjectIdForAdmin { get; set; }

    
    public DbSet<GetAgentsList>? GetAgentsLists { get; set; }
    public DbSet<GetEstateBrokersWithAgentCounts>? GetEstateBrokersWithAgentCounts { get; set; }
    public DbSet<GetRentalProperties>? GetRentalProperties { get; set; }
    public DbSet<GetFilters>? GetFilters { get; set; }
    public DbSet<GetBuyPropertiesAssociatedCounts>? GetBuyPropertiesAssociatedCounts { get; set; }
    public DbSet<GetRentalPropertiesAssociatedCounts>? GetRentalPropertiesAssociatedCounts { get; set; }
    public DbSet<GetBuyPropertyPurchaseCostsCash>? GetBuyPropertyPurchaseCostsCash { get; set; }
    public DbSet<GetBuyPropertyPurchaseMortgageCosts>? GetBuyPropertyPurchaseMortgageCosts { get; set; }
    public DbSet<GetRentalPropertyDetails>? GetRentalPropertyDetails { get; set; }
    public DbSet<GetRentalPropertyCosts>? GetRentalPropertyCosts { get; set; }
    public DbSet<GetNewProjects>? GetNewProjects { get; set; }
    public DbSet<GetNewProjectDetails>? GetNewProjectDetails { get; set; }

    public DbSet<GetAgentUsers>? GetAgentUsers { get; set; }

    public DbSet<GetMediaByBuyPropertyIdForAdminPanel>? GetMediaByBuyPropertyIdForAdminPanel { get; set; }

    public DbSet<GetPropertyConfigurationDetail>? GetPropertyConfigurationDetails { get; set; }

    public DbSet<GetRealEstateBrokers>? GetRealEstateBrokers { get; set; }

    public DbSet<GetDevelopers>? GetDevelopers { get; set; }



}

